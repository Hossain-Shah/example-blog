from django.apps import AppConfig


class PostcommentrestapiConfig(AppConfig):
    name = 'PostCommentRestApi'
