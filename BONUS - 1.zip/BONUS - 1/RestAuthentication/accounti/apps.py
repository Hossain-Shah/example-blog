from django.apps import AppConfig


class AccountiConfig(AppConfig):
    name = 'accounti'
