from django.db import models

class Post(models.Model):
    userId = models.IntegerField()
    id = models.IntegerField(primary_key=True)
    title = models.TextField() 
    body = models.TextField() 
     

    def __str__(self):
        return self.userId, self.id, self.title, self.body


class Comment(models.Model):
    postId = models.IntegerField()
    id = models.IntegerField(primary_key=True)
    name = models.TextField()
    email = models.TextField() 
    body = models.TextField()


    def __str__(self):
        return self.postId, self.id, self.name, self.email, self.body
 

